package edu.corvinus._beadando_Y2AE1G.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name="user_data")
public class PersonForm {

        @Id
        @GeneratedValue
        private int id;

        @NotBlank(message = "A név megadása kötelező")
        private String nev;

        @NotBlank(message = "A felhasználónév megadása kötelező")
        @Size(min=6, message = "A felhasználónévnek legalább 6 karaktert kell tartalmaznia")
        private String felhasznalonev;

        @NotBlank(message = "A jelszó megadása kötelező")
        @Size(min=8, message = "A jelszónak legalább 8 karaktert kell tartalmaznia")
        @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$", message = "A jelszónak legalább egy betűt és egy számot kell tartalmaznia")
        private String jelszo;

        public String getNev() {return nev;}

        public void setNev(String nev) {this.nev = nev;}

        public String getFelhasznalonev() {return felhasznalonev;}

        public void setFelhasznalonev(String felhasznalonev) {this.felhasznalonev = felhasznalonev;}

        public String getJelszo() {return jelszo;}

        public void setJelszo(String jelszo) {this.jelszo = jelszo;}

        @Override
        public String toString() {
                return "PersonForm{" +
                        "nev='" + nev + '\'' +
                        ", felhasznalonev='" + felhasznalonev + '\'' +
                        ", jelszo='" + jelszo + '\'' +
                        '}';
        }
}
