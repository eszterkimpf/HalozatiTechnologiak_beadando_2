package edu.corvinus._beadando_Y2AE1G.repository;

import edu.corvinus._beadando_Y2AE1G.models.User;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface UserRepository extends CrudRepository <User, Integer>{
    Optional<User> findByFelhasznalonev(String felhasznalonev);
}
