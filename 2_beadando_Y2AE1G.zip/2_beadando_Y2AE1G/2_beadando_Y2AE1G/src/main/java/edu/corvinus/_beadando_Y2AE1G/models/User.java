package edu.corvinus._beadando_Y2AE1G.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name="user_data")
public class User {

    @Id
    @GeneratedValue
    private int id;

    private String nev;
    private String felhasznalonev;
    private String jelszo;

    public String getNev() {return nev;}

    public void setNev(String nev) {this.nev = nev;}

    public String getFelhasznalonev() {return felhasznalonev;}

    public void setFelhasznalonev(String felhasznalonev) {this.felhasznalonev = felhasznalonev;}

    public String getJelszo() {return jelszo;}

    public void setJelszo(String jelszo) {this.jelszo = jelszo;}

    @Override
    public String toString() {
        return "User{" +
                "nev='" + nev + '\'' +
                ", felhasznalonev='" + felhasznalonev + '\'' +
                ", jelszo='" + jelszo + '\'' +
                '}';
    }
}
