package edu.corvinus._beadando_Y2AE1G.controllers;

import edu.corvinus._beadando_Y2AE1G.models.PersonForm;
import edu.corvinus._beadando_Y2AE1G.models.User;
import edu.corvinus._beadando_Y2AE1G.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.validation.Valid;
import java.util.Optional;


@Controller
public class WebController implements WebMvcConfigurer {


    @Autowired
    private UserRepository userrepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/results").setViewName("results");
    }

    @GetMapping("/")
    public String showForm(PersonForm personForm) {

        return "regisztracio";

    }

    @PostMapping("/login")
    public String login(@RequestParam(required = false) String felhasznalonev, String jelszo, Model model) {

        Optional<User> foundUser = userrepo.findByFelhasznalonev(felhasznalonev);
        if (foundUser.isEmpty()) {
            model.addAttribute("hianyzik","A felhasználónév nem létezik");
            return "bejelentkezes";
        }

        final User u = foundUser.get();

        if (!passwordEncoder.matches(jelszo, u.getJelszo()))
        {
            model.addAttribute("hibas","Hibás jelszó");
            return "index";
        }

        return "results";
    }

    @PostMapping("/register")
    public String register(@Valid PersonForm personForm, Model model, BindingResult bindingResult) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("hiba","A beírt adatok nem felelnek meg a követelményeknek");
            return "regisztracio";
        }

        Optional<User> foundUser = userrepo.findByFelhasznalonev(personForm.getFelhasznalonev());
        if (!foundUser.isEmpty()) {
            model.addAttribute("foglalt","Ez a felhasználónév már létezik");
            return "regisztracio";
        }

        System.out.println(personForm.toString());

        User felh = new User();
        felh.setFelhasznalonev(personForm.getFelhasznalonev());
        felh.setNev(personForm.getNev());
        felh.setJelszo(passwordEncoder.encode(personForm.getJelszo()));
        System.out.println(felh.toString());
        User new_user = userrepo.save(felh);

        return "bejelentkezes";
    }

    @PostMapping("/bejelentkezes")
    public String bejelentkezes() {return "bejelentkezes";}

    @PostMapping("/regisztracio")
    public String regisztracio() {return "regisztracio";}

}
